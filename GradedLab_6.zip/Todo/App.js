import React from 'react';
import { SafeAreaView, StatusBar,View } from 'react-native';
import HomeScreen from './screens/HomeScreen';

const App = () => {
  return (
    <View style={{ flex: 1 }}>
      <StatusBar barStyle="dark-content" backgroundColor="#f5f5f5" />
      <HomeScreen />
    </View>
  );
};

export default App;