import firestore from '@react-native-firebase/firestore';

export const tasksCollection = firestore().collection('tasks');

export const taskService = {
  // Add task
  addTask: async (task) => {
    try {
      await tasksCollection.add({
        text: task,
        completed: false,
        createdAt: firestore.FieldValue.serverTimestamp(),
      });
    } catch (error) {
      console.error('Error adding task:', error);
      throw error;
    }
  },

  // Get tasks
  getTasks: () => {
    return tasksCollection.orderBy('createdAt', 'desc');
  },

  // Delete task
  deleteTask: async (taskId) => {
    try {
      await tasksCollection.doc(taskId).delete();
    } catch (error) {
      console.error('Error deleting task:', error);
      throw error;
    }
  },

  // Update task
  updateTask: async (taskId, updates) => {
    try {
      await tasksCollection.doc(taskId).update(updates);
    } catch (error) {
      console.error('Error updating task:', error);
      throw error;
    }
  },
};