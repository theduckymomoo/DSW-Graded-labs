import React, { useState } from 'react';
import { StyleSheet, View, TextInput, Button, FlatList, Text, TouchableOpacity } from 'react-native';

function App() {
    const [tasks, setTasks] = useState([]);
    const [taskText, setTaskText] = useState('');

    function addTask() {
        const trimmedTaskText = taskText.trim();
        if (trimmedTaskText.length > 0) {
            const newTask = {
                id: Date.now().toString(),
                text: trimmedTaskText,
                done: false,
            };
            setTasks([...tasks, newTask]);
            setTaskText('');
        }
    }

    function toggleTask(id) {
        setTasks(
            tasks.map(function(task) {
                return task.id === id ? { ...task, done: !task.done } : task;
            })
        );
    }

    function deleteTask(id) {
        setTasks(tasks.filter(function(task) {
            return task.id !== id;
        }));
    }

    function renderItem({ item }) {
        return (
            <View style={styles.taskItem}>
                <TouchableOpacity onPress={function() { toggleTask(item.id); }} style={styles.checkbox}>
                    <Text style={styles.checkboxText}>
                        {item.done ? '✅' : '⬜'}
                    </Text>
                </TouchableOpacity>
                <Text
                    style={[styles.taskText, item.done && styles.taskTextDone]}
                    onPress={function() { toggleTask(item.id); }}
                >
                    {item.text}
                </Text>
                <TouchableOpacity onPress={function() { deleteTask(item.id); }} style={styles.deleteButton}>
                    <Text style={styles.deleteButtonText}>❌</Text>
                </TouchableOpacity>
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <View style={styles.inputRow}>
                <TextInput
                    style={styles.input}
                    placeholder="Enter new task"
                    value={taskText}
                    onChangeText={setTaskText}
                />
                <Button title="Add" onPress={addTask} />
            </View>
            <FlatList
                data={tasks}
                keyExtractor={function(item) { return item.id; }}
                renderItem={renderItem}
                contentContainerStyle={styles.listContainer}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingTop: 50,
        paddingHorizontal: 20,
        backgroundColor: '#f9f9f9',
    },
    inputRow: {
        flexDirection: 'row',
        marginBottom: 20,
        alignItems: 'center',
    },
    input: {
        flex: 1,
        borderColor: '#ccc',
        borderWidth: 1,
        padding: 10,
        borderRadius: 5,
        backgroundColor: '#fff',
    },
    listContainer: {
        paddingBottom: 20,
    },
    taskItem: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#fff',
        paddingVertical: 15,
        paddingHorizontal: 10,
        borderRadius: 5,
        marginBottom: 10,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.1,
        shadowRadius: 1,
        elevation: 2,
    },
    taskText: {
        flex: 1,
        fontSize: 18,
        color: '#333',
    },
    taskTextDone: {
        textDecorationLine: 'line-through',
        color: '#888',
    },
    checkbox: {
        marginRight: 10,
    },
    checkboxText: {
        fontSize: 24,
    },
    deleteButton: {
        marginLeft: 10,
        padding: 5,
    },
    deleteButtonText: {
        fontSize: 20,
        color: 'red',
    },
});

export default App;