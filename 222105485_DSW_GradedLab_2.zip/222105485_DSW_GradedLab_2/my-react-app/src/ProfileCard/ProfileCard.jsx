import React from 'react';
import './ProfileCard.css';

const ProfileCard = ({ image, name, title, bio }) => {
  return (
    <div className="profile-card">
      <img src={image} alt={`${name}'s profile`} className="profile-image" />
      <h2 className="profile-name">{name}</h2>
      <h4 className="profile-title">{title}</h4>
      <p className="profile-bio">{bio}</p>
    </div>
  );
};

export default ProfileCard;