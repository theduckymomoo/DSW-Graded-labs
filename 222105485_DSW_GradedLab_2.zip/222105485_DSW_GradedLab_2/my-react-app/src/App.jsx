import React from 'react';
import ProfileCard from './ProfileCard/ProfileCard.jsx';
import './App.css'; 
import kevinImage from './images/kevin.jpg';
import kobeImage from './images/kobe.jpg';  

function App() {
  return (
    <div className="app-container">
      <h1>Basketball Legends</h1>
      <div className="profile-cards-container">
        <ProfileCard
          image={kevinImage}
          name="Kevin Durant"
          title="Basketball Player"
          bio="Kevin Durant is a professional basketball player known for his scoring ability and versatility."
        />
        <ProfileCard
          image={kobeImage}
          name="Kobe Bryant"
          title="Former Basketball Player"
          bio="Kobe Bryant was an American professional basketball player, widely regarded as one of the greatest players of all time."
        />
      </div>
    </div>
  );
}

export default App;